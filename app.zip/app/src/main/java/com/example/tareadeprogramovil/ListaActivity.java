package com.example.tareadeprogramovil;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class ListaActivity extends AppCompatActivity {

    private List<Restaurante> listaOriginal;
    private RestauranteAdapter adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);

        RecyclerView rv = findViewById(R.id.rvRestaurantes);
        EditText etBuscar = findViewById(R.id.etBuscar);

        // Crear restaurantes de ejemplo
        listaOriginal = new ArrayList<>();
        listaOriginal.add(new RestauranteCasual("Casualito", "Centro", 40, "Mexicana", 4.2, true, 10));
        listaOriginal.add(new RestauranteGourmet("GourmetChef", "Zona Alta", 20, "Francesa", 4.8, 5, 60));
        listaOriginal.add(new FoodTruck("Rápido y Sabroso", "Calles", 30, "Tacos", 4.1, "Centro", "Carnitas", 8));

        adaptador = new RestauranteAdapter(listaOriginal);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adaptador);

        etBuscar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filtrar(s.toString());
            }
        });
    }

    private void filtrar(String texto) {
        List<Restaurante> filtrados = new ArrayList<>();
        for (Restaurante r : listaOriginal) {
            if (r.getUbicacion().toLowerCase().contains(texto.toLowerCase()) ||
                    r.getTipoCocina().toLowerCase().contains(texto.toLowerCase())) {
                filtrados.add(r);
            }
        }
        adaptador.actualizarLista(filtrados);
    }
}