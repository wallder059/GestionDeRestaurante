package com.example.tareadeprogramovil;

public class RestauranteCasual extends Restaurante {
    private boolean menuFijo;
    private double costoMenuFijo;

    public RestauranteCasual(String nombre, String ubicacion, int capacidad, String tipoCocina, double calificacionMedia,
                             boolean menuFijo, double costoMenuFijo) {
        super(nombre, ubicacion, capacidad, tipoCocina, calificacionMedia);
        this.menuFijo = menuFijo;
        this.costoMenuFijo = costoMenuFijo;
    }

    @Override
    public double calcularIngresoEstimado() {
        return capacidad * costoMenuFijo * 0.8;
    }
}