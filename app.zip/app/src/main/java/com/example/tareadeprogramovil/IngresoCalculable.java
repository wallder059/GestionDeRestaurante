package com.example.tareadeprogramovil;

public interface IngresoCalculable {
    double calcularIngresoEstimado();
    
}

