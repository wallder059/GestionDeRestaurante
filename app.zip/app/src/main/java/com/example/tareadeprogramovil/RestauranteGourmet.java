package com.example.tareadeprogramovil;

public class RestauranteGourmet extends Restaurante {
    private int numeroPlatosExclusivos;
    private double costoDegustacion;

    public RestauranteGourmet(String nombre, String ubicacion, int capacidad, String tipoCocina, double calificacionMedia,
                              int numeroPlatosExclusivos, double costoDegustacion) {
        super(nombre, ubicacion, capacidad, tipoCocina, calificacionMedia);
        this.numeroPlatosExclusivos = numeroPlatosExclusivos;
        this.costoDegustacion = costoDegustacion;
    }

    @Override
    public double calcularIngresoEstimado() {
        return capacidad * costoDegustacion * 0.6;
    }
}